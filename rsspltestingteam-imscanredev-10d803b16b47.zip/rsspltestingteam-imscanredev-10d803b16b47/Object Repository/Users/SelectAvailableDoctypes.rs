<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SelectAvailableDoctypes</name>
   <tag></tag>
   <elementGuidId>57219638-3f58-4d2c-9017-a74ad2a50045</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//li[text()='RSSPL Doc type']</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
