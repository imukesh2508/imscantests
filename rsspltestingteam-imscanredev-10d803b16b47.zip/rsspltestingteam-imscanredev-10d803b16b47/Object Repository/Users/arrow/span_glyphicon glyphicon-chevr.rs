<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_glyphicon glyphicon-chevr</name>
   <tag></tag>
   <elementGuidId>be71a1c2-362f-4b4d-ba19-aa85568a979f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;UserContentForm&quot;)/div[@class=&quot;modal-dialog&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/form[@class=&quot;form-horizontal&quot;]/div[@class=&quot;form-group&quot;]/div[@class=&quot;col-sm-12 permission-duallist&quot;]/div[@class=&quot;list-arrows col-md-2 col-xs-2 text-center&quot;]/button[@class=&quot;btn btn-default btn-sm userDept-move-right&quot;]/span[@class=&quot;glyphicon glyphicon-chevron-right&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>glyphicon glyphicon-chevron-right</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;UserContentForm&quot;)/div[@class=&quot;modal-dialog&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/form[@class=&quot;form-horizontal&quot;]/div[@class=&quot;form-group&quot;]/div[@class=&quot;col-sm-12 permission-duallist&quot;]/div[@class=&quot;list-arrows col-md-2 col-xs-2 text-center&quot;]/button[@class=&quot;btn btn-default btn-sm userDept-move-right&quot;]/span[@class=&quot;glyphicon glyphicon-chevron-right&quot;]</value>
   </webElementProperties>
</WebElementEntity>
