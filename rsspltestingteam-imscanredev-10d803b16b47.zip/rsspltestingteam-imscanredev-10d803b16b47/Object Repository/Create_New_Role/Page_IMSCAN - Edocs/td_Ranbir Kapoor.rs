<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_Ranbir Kapoor</name>
   <tag></tag>
   <elementGuidId>5e144b36-11a1-4b36-9e5e-dbcd3e6d7db9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//td[(text() = 'Randheer Kapoor' or . = 'Randheer Kapoor')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ellipsisClass sorting_1</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Randheer Kapoor</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;role-listing&quot;)/tbody[1]/tr[@class=&quot;odd&quot;]/td[@class=&quot;ellipsisClass sorting_1&quot;]</value>
   </webElementProperties>
</WebElementEntity>
