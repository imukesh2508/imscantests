<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Create Role</name>
   <tag></tag>
   <elementGuidId>c4fc5705-bc7b-45a9-b5f2-a4445ef6be89</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span[@id='createRole']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;createRole&quot;)[count(. | //span[@id = 'createRole' and @data-toggle = 'modal' and @data-target = '#role-modal' and (text() = 'Create Role' or . = 'Create Role')]) = count(//span[@id = 'createRole' and @data-toggle = 'modal' and @data-target = '#role-modal' and (text() = 'Create Role' or . = 'Create Role')])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
