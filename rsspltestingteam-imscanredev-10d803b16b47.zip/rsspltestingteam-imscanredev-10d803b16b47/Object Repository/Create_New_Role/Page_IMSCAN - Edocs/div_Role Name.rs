<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Role Name</name>
   <tag></tag>
   <elementGuidId>d5c88c20-186f-4bdb-b3e5-b9148c5eb183</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>modal-body</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                    
                        
                            Role Name* :
                            
                                
                                
                            
                        
                        
                            Available Permissions:
                            
                            Assigned Permissions* :
                            
                                
                                    
                                        Document ScanningDocument Batch ManagementDocument IndexingDocument Indexing-Allow Validation OverrideDocument Retrieval-Document UpdatingDocument Retrieval-Document DeletionDocument Retrieval-Document Edit TitleDocument Retrieval-Document ExportingDocument Retrieval-No PrintingDocument Retrieval-No EmailingDocument Retrieval-No Launch External ViewerWorkflow-Document RemovalWorkflow-Document UpdatingProcessing-Process FilesProcessing-View LogsProcessing-Notify of Process ErrorProcessing-Notify of Process WarningProcessing-Notify of Completed Disk IDProcessing-Notify of Write CDAdministrator Role-Setup UsersAdministrator Role-General SettingsAdministrator Role-SMTP SettingsAdministrator Role-Email SetupAdministrator Role-Database ConnectionsAdministrator Role-ReportingAdministrator Role-Email FormatsAdministrator Role - Document Type SetupDynamic Forms-Document creationDynamic Forms-Draft ListingDocument ImportingImscan AdminImscan User
                                    
                                

                                
                                    
                                        
                                    
                                    
                                        
                                    
                                

                                
                                    
                                                                           
                                     
                                    
                                
                            
                        
                        

                        
                        
                            
                                Close
                                Save
                            
                        

                    

                </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;roleContentForm&quot;)/div[@class=&quot;modal-dialog&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]</value>
   </webElementProperties>
</WebElementEntity>
