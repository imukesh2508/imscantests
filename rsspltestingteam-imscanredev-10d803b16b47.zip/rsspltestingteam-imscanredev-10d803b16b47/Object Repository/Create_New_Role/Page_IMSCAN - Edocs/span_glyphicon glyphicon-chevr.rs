<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_glyphicon glyphicon-chevr</name>
   <tag></tag>
   <elementGuidId>7ef3b425-152d-49fc-b3b9-4a9c1cefbe58</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>glyphicon glyphicon-chevron-right</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;roleContentForm&quot;)/div[@class=&quot;modal-dialog&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/form[@class=&quot;form-horizontal&quot;]/div[@class=&quot;form-group&quot;]/div[@class=&quot;col-sm-12 permission-duallist&quot;]/div[@class=&quot;list-arrows col-md-2 col-xs-2 text-center&quot;]/button[@class=&quot;btn btn-default btn-sm rolePerm-move-right&quot;]/span[@class=&quot;glyphicon glyphicon-chevron-right&quot;]</value>
   </webElementProperties>
</WebElementEntity>
