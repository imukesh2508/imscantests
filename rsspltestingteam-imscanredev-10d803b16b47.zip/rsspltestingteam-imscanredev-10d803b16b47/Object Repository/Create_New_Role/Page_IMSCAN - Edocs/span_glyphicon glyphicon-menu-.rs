<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_glyphicon glyphicon-menu-</name>
   <tag></tag>
   <elementGuidId>d4b64c7a-9321-463d-9f93-72fb1656815d</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>glyphicon glyphicon-menu-down</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;wrapper&quot;]/div[@class=&quot;page-container&quot;]/header[1]/div[@class=&quot;titlebar&quot;]/div[@class=&quot;col-md-4 col-sm-3 col-xs-7 iconoptions text-right&quot;]/ul[@class=&quot;titlebarOptions&quot;]/li[@class=&quot;profile dropdown dropdown-submenu&quot;]/a[@class=&quot;collapsed&quot;]/div[@class=&quot;profile-usertitle&quot;]/div[@class=&quot;profile-usertitle-name&quot;]/span[@class=&quot;glyphicon glyphicon-menu-down&quot;]</value>
   </webElementProperties>
</WebElementEntity>
