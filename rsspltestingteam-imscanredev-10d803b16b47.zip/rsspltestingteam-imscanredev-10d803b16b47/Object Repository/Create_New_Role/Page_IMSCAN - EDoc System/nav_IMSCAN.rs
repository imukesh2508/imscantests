<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>nav_IMSCAN</name>
   <tag></tag>
   <elementGuidId>664b9b48-2164-4ebb-a55c-c8419ed4f402</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>nav</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>sidemenu</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>navbar navbar-default sidebar mainmenu ps ps--active-x</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>navigation</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            
                
                    
                        IMSCAN
                        

                            
                                
                                
                                
                            
                        
                        
                    
                    
                        
                            
                                
                            
                            
                                John Doe

                            
                        
                    

                    
                        
                            
                                Home
                                
                                    
                                    
                                
                            
                        
                        
                            
                                User Role
                                
                                    
                                    
                                
                            
                        
                                                
                            
                                Departments
                                
                                    
                                    
                                
                            
                        
                                                
                            
                                Users
                                
                                    
                                    
                                
                            
                        
                                                
                            
                                Document Type
                                
                                    
                                    
                                
                            
                        
                                                
                            
                                Dynamic Document Type
                                
                                    
                                    
                                
                            
                            
                        
                                                
                            
                                Scanning
                                
                                    
                                    
                                
                            
                        
                                                
                            
                                Settings
                                
                                    
                                    
                                
                            
                        
                                                
                            
                                Importing
                                
                                    
                                    
                                
                            
                        
                                                
                            
                                Retrieval
                                
                                    
                                    
                                
                            
                        
                                                
                            
                                Workflow
                                
                                    
                                    
                                
                            
                        
                                                    
                                
                                    Indexing
                                    
                                        
                                        
                                    
                                
                            
                    

                
            
        </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sidemenu&quot;)</value>
   </webElementProperties>
</WebElementEntity>
