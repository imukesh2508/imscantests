<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_User Role</name>
   <tag></tag>
   <elementGuidId>76d00a52-d6f1-40ba-aa77-e4e8e20c4bf4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;role_Partial&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;role_Partial&quot;)[count(. | //*[@id = 'role_Partial' and @title = 'User Role' and (text() = '
                                User Role
                                
                                    
                                    
                                
                            ' or . = '
                                User Role
                                
                                    
                                    
                                
                            ')]) = count(//*[@id = 'role_Partial' and @title = 'User Role' and (text() = '
                                User Role
                                
                                    
                                    
                                
                            ' or . = '
                                User Role
                                
                                    
                                    
                                
                            ')])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>#</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>role_Partial</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>User Role</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                User Role
                                
                                    
                                    
                                
                            </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;role_Partial&quot;)</value>
   </webElementProperties>
</WebElementEntity>
