<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_John Doe</name>
   <tag></tag>
   <elementGuidId>cb8ee312-9f7a-4a0b-aad7-fdd98a2d7ca3</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>profile-usertitle-name</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>John Doe</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;wrapper&quot;]/div[@class=&quot;page-container&quot;]/header[1]/div[@class=&quot;titlebar&quot;]/div[@class=&quot;col-md-4 col-sm-3 col-xs-7 iconoptions text-right&quot;]/ul[@class=&quot;titlebarOptions&quot;]/li[@class=&quot;profile dropdown dropdown-submenu&quot;]/a[@class=&quot;collapsed&quot;]/div[@class=&quot;profile-usertitle&quot;]/div[@class=&quot;profile-usertitle-name&quot;]</value>
   </webElementProperties>
</WebElementEntity>
