<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Selecting1stEntryfromSearch</name>
   <tag></tag>
   <elementGuidId>af6e1b0f-d801-40fb-85d7-e75eca7461b7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//tr[1])[3]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
