<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ClickOnEdit(2)</name>
   <tag></tag>
   <elementGuidId>7f457e8a-08aa-44a5-aedf-b763c501e8cb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//i[@class='fa fa-pencil iconsInTable'])[2]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
