<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ElementToBeEdited(2)</name>
   <tag></tag>
   <elementGuidId>81e0898f-d902-43b1-8746-7af257f38ec7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//td[@class='sorting_1'])[7]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
