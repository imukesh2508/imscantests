<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Select1stReportFromList</name>
   <tag></tag>
   <elementGuidId>5f63d658-f922-4147-baef-e6f70abbf271</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//ul[@class='nav nav-pills nav-stacked  VHScrollForReports']/li/a)[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
