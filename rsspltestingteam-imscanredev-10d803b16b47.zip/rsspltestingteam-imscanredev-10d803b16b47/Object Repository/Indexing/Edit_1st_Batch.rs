<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Edit_1st_Batch</name>
   <tag></tag>
   <elementGuidId>0f54817f-8431-46f8-9df7-97ebc2fc57f8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//table[@id='tblIndexingBatchList']//tbody/tr)[2]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
