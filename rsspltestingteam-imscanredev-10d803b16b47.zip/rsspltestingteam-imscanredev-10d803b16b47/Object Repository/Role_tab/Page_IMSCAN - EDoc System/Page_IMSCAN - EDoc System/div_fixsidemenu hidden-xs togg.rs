<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_fixsidemenu hidden-xs togg</name>
   <tag></tag>
   <elementGuidId>6f0858ba-2e3d-43a4-854b-cb8c29b4e786</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fixsidemenu hidden-xs toggleCheckbox</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;bs-sidebar-navbar-collapse-1&quot;)/div[@class=&quot;fixsidemenu hidden-xs toggleCheckbox&quot;]</value>
   </webElementProperties>
</WebElementEntity>
