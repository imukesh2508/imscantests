<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Search_Inspect</name>
   <tag></tag>
   <elementGuidId>0092fb69-8ee6-4a48-8975-26bd45bde3be</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>//input[@type='search']</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
