<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Selecting1stEntryfromSearchfield</name>
   <tag></tag>
   <elementGuidId>37b2144b-8816-4dee-86b1-e5ca731583a7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//tbody/tr[1])[2]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
