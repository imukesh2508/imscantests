<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Smoke</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2018-10-12T14:50:57</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>34840e92-fd08-4d66-a49a-1be8151e0751</testSuiteGuid>
   <testCaseLink>
      <guid>677aebcb-c9fa-4874-a269-8621ba458fcc</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-09</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8d46b2b4-8eab-4e5f-b1d7-33b34dfd93b9</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-1 Creating a new Department</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>58f6e0c2-b3f4-4851-8ad7-7ee89f918dd1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-123</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>857f2627-06ae-4e25-8e73-9c40e4b1ffbc</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-143_Login_ValidLogin</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7b3a736a-f21e-4f1c-80b9-646355a746b1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-145_Login_InvalidLogin</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>a68a98ba-8b27-40d5-a018-6bb4afda63e2</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-164</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>4bafeee0-116d-46b7-84c8-90362c27e046</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-18_Create_New_Role</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>adebd5fa-7f86-465c-8982-1ac6e8e51509</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-26</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8f6b5b91-b4d7-45b1-972e-8cd2ee86aa2c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-356</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>a3ef3608-752c-4966-a681-bf4f9f148b6c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-43</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>fa23e69f-5b1d-4e28-94c4-354e58fe1765</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-46</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>bbf6cf7a-2332-49b8-b451-fec22c2b597b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-48</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>777b20e9-a768-4a6f-89ec-d593c9ff7c7c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-536</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>75e416f8-58f2-4763-8d98-325d774186e9</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-62</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>319fddcf-4689-4f62-93a8-4ae256dc2453</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-68</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>12e5f795-11c3-4264-b872-ae2224d75ace</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-86</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>495be0dc-f5c0-4627-b49c-f7777e17a91d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-493</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d7fabf66-9bbb-42b1-8572-42e1b3652e67</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-532</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>01ed2b70-2328-49b9-a101-cf7c40d3a8a6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-610</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>be5a46ac-0d24-409e-825b-9389d207d003</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-676</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>52c28b0f-7333-4bd5-a3d0-9f16110c28c7</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-725</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e74a4e6b-88a3-415f-8878-552f6c3e0a30</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-764</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7fc5610a-4fff-4ddd-ba71-17268b7cacc8</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-771</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>54747ea8-a003-462a-b9f6-7b15554092ee</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-832</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>2c68093b-fe47-44b6-b393-74d916c17eff</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-837</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>eb6bfc8d-a5f7-4a27-9626-9aac99e00987</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-849</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>c2c3666e-ec4f-41e6-b1e8-508b5a5ab7ef</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-842</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>63bc8699-28b5-4c43-9a62-ec52845f6214</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/TC-Batch _ Details</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>0305d2e6-d4e4-464a-a459-7a843524bde2</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Smoke/ToPerformenabledOptionOnThedocumentInWorkflow</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
